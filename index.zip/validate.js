function objects(req, object) {
  if (Object.keys(object).length === 0) return true;
  else
    for (var key in object) {
      var schema = object[key]
      var check = joi.validate(req.object[key], schema).err === null
      if (!check) return false;
    }
  return true;
}

function parameter(req, {query, headers, body}) {
  // headers
  const check = req.method === 'get'
    ? !validateObjectBase(req, query))
    : joi.validation(req.body, body).err === null

  return check && validateObjectBase(req, headers);
}


module.exports = {
  parameter, objects
};
