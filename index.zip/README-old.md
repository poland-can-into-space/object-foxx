# Json Server
## summary
Aim of this project is to reduce learning cost and development time for foxx development.
While foxx resembles express server from nodejs, it is different in many ways and most people are not familiar with.
The aim of this project is to
1. make things more obvious
2. reduce learning cost and speed up development
3. make things more DRY

## getting started
```
const {
  joiAliases,
  AQL, // will be explained later
  main
} = require("json-server")
const routes = [
  ... lots of route object  // will be explained later
]
const config = {
  ... configulation  // will be explained later
}
main(routes, config)
```

## Features
### joiAliases
1. summary
function. it returns joi schema
```
function joiAliases() {
  const joi = require('joi');
  return {
    // short hand
    object: joi.object,
    string: joi.string,
    number: joi.number,
    array: joi.array,
    boolean: joi.boolean,
    // even shorter
    obj: joi.object,
    str: joi.string,
    num: joi.number,
    array: joi.array,
    bool: joi.boolean
  }
};
```
it should make your life easier.
### AQL
1. overview
AQL (all letters in uppercase) is a function designed to reduce the time for writing bindVars and error checking for aql query.
It takes 2 arguments; 1st argument must be a aql query(string) or a object with key prop {key: "key"}.
- arg1 -> when it is an object
When arg1 is an object, the corresponding aql will be fetched from config schema's aqls property.
In case non are found, it will return an error.
- arg1 -> when it is a string
it will be an aql query and it will be passed down to query parameter on db.\_query just like the below example.
- arg2 -> when an object is passed
arg2 is entirely optional but when it is passed down, it will be merged with request object which will be accessible in aql.
2. in a nut shell
The function works as follow.
```
const query = arg1.key
  ? config.aqls[arg1.key]
  : arg1
const bindVars = Object.assign(req, arg2)
return db._query({ query, bindVars })._documents;
```
3. Tips
- accessing variables
You can do it like this since the entire request object is assigned as a variable.
```
filter
  @body.user == DOCUMENT("Users/123")
```
However, _If you are trying to specify a collection based on the input of bindVars you must specify it manually_

2. calling pre-registered aql function
Instead of string, you can give arg1 an object.
```
{
  key: <<key of the aql funciton assigned at config schema>>
}
```
In this case, it will find a corresponding aql query from config schema and execute it.

### Deciding status code automatically
It is pretty painful and costly to define status code in each routes explicitly.
function defined at route.func will return a value instead of sending response within the function with res.send()
Value returned will be matched against schema defined in response property.
Following rules will be applied if nothing is specified.
- if returned value is an array:
  - when length of the array is longer than 1:
    response body will be "" (empty) and status code will be decided as follow;
    status code will be 200 and response body will be the returned value itself
  - when length of the array is undefined, false, null or true:
    response body will be "" (empty) and status code will be decided as follow;
    null -> 404
    undefined -> 501
    false -> 403
    true -> 204
- if returned value doesn't match any of the above
  status code will be 200 and the response body will be the returned value itself

_not that returned body will be passed to JSON.strngify before the response is sent if it is an object_

### automatic error checking
any aql function defined on config schema will be checked at compile time.
The result will be saved on JsonServer_AqlResult.
Results can be fetched with the route json-server will automatically add to your routes.

## config schema
```
{
  // this is where you put your functions. It will be invoked on router.use()
  use: array of object with functions,
  // aqls that will be parsed
  aqls: array or object with aql strings,
}
```

## route schema
exampe:
```
{
  method: "get",
  path: "/:path1",
  func: function () {

  },
  request: {
    body: "joi schema for request body",
    headers: {
      header1: "joi schema for header1"
      header2: "joi schema for header2"
    },
    query: {
      query1: "joi schema for query 1",
      query2: "joi schema for query 2"
      query3: "joi schema for query 2"
    },
    path: {
      path1: "joi schema for path parameter 1"
    }
  },
  response: [
    {
      schema: "joi schema",
      status: "status code for this schema"
    }
  ],
  conditions: [
    "condition1" // this is the condition which must be met in order to invoke the func
  ]
}
```
