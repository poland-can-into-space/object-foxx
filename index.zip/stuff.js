const exampleRoute = {
  method: "get",
  path: "/path",
  func: function (req, res) {

  },
  request: {

  },
  response: {

  },
  condition: []
}
const exampleLocalConfig = {
  template: {},
  aql: {},
  use: []
}
const exampleGlobalConfig = {
  template: function (req, res, next) {

  },
  conditions: {},
  aql: {},
  use: []
}

// sets properties
const request = function(route, {body, headers, queryParams}) {
  var r = route;
  if (body) {
    var r = r.body(body)
  }
  if (headers) {
    for (const header of headers) {
      var [name, schema, description] = header
      var r = r.header(name, schema, description)
    }
  }
  if (queryParams) {
    for (const queryParam of queryParams) {
      var [name, schema, description] = queryParam
      var r = r.queryParam(name, schema, description)
    }
  }
  return r;
};
const response = function (route, responses) {
  for (const resp of responses) {
    var [schema, description] = resp;
    var r = route.resopnse(schema, description)
  }
  return r;
}
const info = function (route, {summary}) {
  var r = route;
  if (summary) r.summary(summary);
  return r;
};
// use prop
const use = function (route, use) {
  var r = route
  for (const func of use) var r = r.use(func)
  return r;
}
// conditions
const conditionsToInvoke = function (obj, {glb}) {
  var ar = []
  for (const key of obj.conditions) {
    if (!glb[key]) {
      console.log(`condition function ${el} is not found.`);
    } else if (glb[key]) {
      ar.push([key, glb[el]])
    }
  }
  const gen = function* (req, res) {
    for (const [key, func] of ar) {
      yield func(req, res)
    }
  }
  //condCheck
  return function (req, res) {
    const genObj = gen(req, res)
    for (const value of genObj) {
      if (value === true) {
        const status = y.status || 508
        const body = typeof value === 'object'
         ? JSON.stringify(y.body)
         : y.body

        res.status(status).send(body)
      }
    }
    return true;
  }
}
//takes the router object and sets response, request and summary property
function makeRoute(router, obj, {glb, local}) {
  var rawResp = false;
  const condCheck = conditionsToInvoke(obj, {glb});
  if (local.template === 'function' && !obj.disableTemplate) {
    var r = router[obj.method](obj.path, function (req, res) {
      if (condCheck(req, res)) {
        local.template({res, req}, obj.func)
      }
    })
  } else if (glb.template === 'function' && !obj.disableTemplate){
    var r = router[obj.method](obj.path, function (req, res) {
      if (condCheck(req, res)) {
        glb.template({res, req}, obj.func)
      }
    })
  } else {
    var r = router[obj.method](obj.path, function (req, res) {
      if (condFuncs(req, res)) {
        obj.func(req, res)
      }
    })
    var rawResp = true
  }

  if (obj.request) var r = request(r, obj.request)

  if (!rawResp && obj.response) var r = response(r, obj.response)

  var r = info(r, obj)
}

function main(routes, routerConfig, moduleConfig) {
  const glb = routerConfig.global
  const local = routerConfig.local
  const router = createRouter()
  for (const route of routes) {
    makeRoute(router, route, {glb, local})
  }
  const {tag, suffix} = typeof moduleConfig === 'object' ? moduleConfig : {}
  tag && router.tag(tag)
  module.context.use(suffix || "/", router, tag || "no tag specified")
}
