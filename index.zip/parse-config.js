const db = require('@arangodb').db;

function create() {
  try {
    db._createCollection("JsonServer")
  } catch (e) {

  }
}

function parse(str) {
  try {
    return {error: false, detail: db._createStatement(str).parse()}
  } catch (e) {
    return {error: true, detail: e};
  }
}

function saveParseResult(aqlKey, aql, id, timestamp) {
  db._collection("JsonServer").save({
    TYPE: "AqlCheck",
    aql,
    aqlKey,
    timestamp,
    processId: id,
    parseResult: parse(string)
  })
}

[
  {

  }
]

function main(o) {
  create()
  const query = `
    return CONCAT(DATE_NOW(), "-", RANDOM_TOKEN(10))
  `
  const id = db._query({query})._documents[0]
  const timestamp = Date.now()
  for (var k in o) {
    const v = o[k]
    saveParseResult(k, v, id, timestamp)
  }
}
